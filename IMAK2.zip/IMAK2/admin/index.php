
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 
<link rel="icon" type="image/png" sizes="16x16" href="plugins/images/favicon.png">
<title>IMAC E-learning system| Admin  Login</title>
 
<script src="js2/gen_validatorv4.js" type="text/javascript"></script>



        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
         
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        
        <link rel="shortcut icon" href="../plugins/images/favicon.png"> 
        <link rel="stylesheet" type="text/css" href="./csslogin/demo.css" />
        <link rel="stylesheet" type="text/css" href="./csslogin/style2.css" />
		
		  
		
		 

		<script type="text/javascript" src="../js2/modernizr.custom.86080.js"></script>


 </head>

 
<body id="page">

        <div class="container">
            <!-- Codrops top bar -->
            <div class="codrops-top">
           
                <span class="right">
                     
                   
                    
                </span>
                <div class="clr"></div>
            </div><!--/ Codrops top bar -->
            <header>
                <h1>IMAM MALIK ACADEMY E-learning System</h1>
				 <p class="codrops-demos">
				   
					 <a  href="index.php"> ADMIN AREA </a>
					 
				</p> <p class="codrops-demos">
        <a  href="../index.php"> Go Home </a>
        </p>
            </header>
			
        
	





<style type="text/css">
<!--
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
	color: #666666;
}
a:active {
	text-decoration: none;
}
-->

  
.login {
  width: 125%;
  margin: -68px auto 0px;
  padding: 15px 0px 0px 0px;
  border-radius: 5px;
   
}
 
.login form input[type="text"] {
  outline: none;
  font-size: 15px;
  font-weight: 400;
  color: #c0c0c0;
  padding: 10px 20px 10px 46px;
  border: 1px solid #2DC2BC;
  border-radius: 5px;
  margin: 0 auto 15px;
  width: 60%;
  -webkit-appearance: none;
}
form {
  padding: 22px 0px 0px 0px;
}
.login input[type="password"] {
  outline: none;
  font-size: 19px;
  font-weight: 400;
  padding: 10px 20px 10px 45px;
  border: 1px solid #2DC2BC;
  border-radius: 5px;
  margin: 0 auto 11px;
  width: 60%;
  -webkit-appearance: none;
  color:#c0c0c0;
}
.login-bwn {
  text-align: center;
}
.login input[type="submit"] {
  background: #2EC1D9;
  color: #FFF;
  font-size: 18px;
  font-weight: 400;
  padding: 6px 0px;
  width: 20%;
  cursor: pointer;
  outline: none;
  margin: 15px 0px 5px 0px;
  border: none;
  border-radius: 5px;
   
}
.login input[type="submit"]:hover {
	background:rgb(160, 6, 6);
	transition: 0.5s all;
  -webkit-transition: 0.5s all;
  -moz-transition: 0.5s all;
  -o-transition: 0.5s all;
}
.login form input.user {
  background: url(images/user.png)no-repeat 15px 7px #fff;
  display: block;
}
.login form input.lock {
  background: url(images/key.png)no-repeat 15px 7px #fff;
  display: block;
}
label.checkbox {
  float: left;
}
.forgot input[type="checkbox"] {
  display: none;
}
.forgot.checkbox input {
	position: absolute;
	left: -9999px;
}
.forgot.checkbox i {
	border-color: #fff;
	transition: border-color 0.3s;
	-o-transition: border-color 0.3s;
	-ms-transition: border-color 0.3s;
	-moz-transition: border-color 0.3s;
	-webkit-transition: border-color 0.3s;
	
}
.forgot.checkbox i:hover {
	border-color:red;
	
}
.forgot i:before {
	background-color: #2da5da;	
}
.forgot  .rating label {
	color: #ccc;
	transition: color 0.3s;
	-o-transition: color 0.3s;
	-ms-transition: color 0.3s;
	-moz-transition: color 0.3s;
	-webkit-transition: color 0.3s;
}
.forgot .checkbox input + i:after {
	position: absolute;
	opacity: 0;
	transition: opacity 0.1s;
	-o-transition: opacity 0.1s;
	-ms-transition: opacity 0.1s;
	-moz-transition: opacity 0.1s;
	-webkit-transition: opacity 0.1s;
}
.forgot .checkbox input + i:after {
  content: url(../images/tick.png) no-repeat 7px 1px;
    top: 2px;
  left: 2px;
  width: 15px;
  height: 15px;
}
.forgot .checkbox {
	padding: 6px 0px 0px 22px;
	font-size: 15px;
	font-weight: 500;
	line-height: 5px;
	color:#c0c0c0;
	cursor: pointer;
	position: relative;
	display: block;
	float: left;
}
.forgot .checkbox:hover {
	text-decoration: none;
}
.forgot .checkbox i {
 position: absolute;
  top: 1px;
  left: 0px;
  display: block;
  width: 16px;
  height: 16px;
  outline: none;
  border: none;
  background: #DDD8D8;
  border-radius: 3px;
}
.forgot  .checkbox input + i:after {
	position: absolute;
	opacity: 0;
	transition: opacity 0.1s;
	-o-transition: opacity 0.1s;
	-ms-transition: opacity 0.1s;
	-moz-transition: opacity 0.1s;
	-webkit-transition: opacity 0.1s;
}
.forgot .checkbox input + i:after {
	color: #2da5da;
}
.forgot.checkbox input:checked + i,
.forgot . input:checked + i {
	border-color: #2da5da;	
}
.forgot .rating input:checked ~ label {
	color: #2da5da;	
}

.forgot .checkbox input:checked + i:after {
	opacity: 1;
}
 
.forgot {
  width: 75%;
  margin: 0 auto;
}
.login-para p {
  padding: 0px 4px 0px 0px;
}
.login-check {
  float: left;
}
.login-para {
  float: right;
}
.login-para p a {
  font-size: 15px;
  font-weight: 400;
  color: rgb(219, 0, 0);
}
.login-para p a:hover {
   color:#999;
   transition: 0.5s all;
  -webkit-transition: 0.5s all;
  -moz-transition: 0.5s all;
  -o-transition: 0.5s all;
}
 
.clear{
	clear:both;
}
 
/*--media quries start here--*/
@media(max-width:1440px){
.login-para p {
  padding: 0px 0px 0px 0px;
}
.forgot {
  width: 73%;	
}
.face-bwn {
  width: 22%;
}

}
@media(max-width:1366px){
.forgot {
  width: 75%;
}

}
@media(max-width:1280px){
.button a {
  font-size: 13px;
}
.button a span {
  margin-top: 10px;
}
.reg-bwn a {
  font-size: 14px;
}
}
@media(max-width:1024px){
.login {
  width: 41%;
}
}
@media(max-width:768px){
.login {
  width: 55%;
}
.login input[type="submit"] {
  font-size: 15px;
    width: 66%;
}
@media (max-width: 640px){
.login {
  width: 70%;
}
.login input[type="submit"] {
  font-size: 15px;
    width: 66%;
}
@media (max-width: 540px){
 
.login input[type="submit"] {
  font-size: 15px;
    width: 66%;
}
}
@media (max-width: 480px){
.login {
  width: 88%;
}
.login input[type="submit"] {
  font-size: 15px;
    width: 66%;
}
}
@media(max-width:440px){
.button a {
  float: none;
  width: 100%;
  margin-bottom: 1em;
}
}
@media (max-width: 320px){
h1 {
  font-size: 1.5em;
}
.login {
  width: 90%;
  margin: 25px auto 0;
  padding: 10px 0px 0px 0px;
}
.login h2 {
  font-size: 22px;
}
form {
  padding: 15px 0px 0px 0px;
}
.login form input[type="text"],.login input[type="password"] {
  font-size: 13px;
    padding: 9px 20px 9px 45px;
	width: 66%;
}
.forgot {
  width: 90%;
}
.forgot .checkbox {
  font-size: 13px;
}
 .login-check {
  margin-top: 3px;
}
.login-para p a {
  font-size: 13px;
}
.login input[type="submit"] {
  font-size: 15px;
    width: 66%;
}
.button a {
  float: none;
  width: 100%;
  margin-bottom: 1em;
}
.button {
  padding: 9px 0px 17px 0px;
}
.login-bottom h4,.login-bottom h4 a {
  font-size: 13px;
}
.reg-bwn a {
  padding: 6px 18px;
}
.login-bottom h3 {
  padding: 15px 0px 0px 0px;
  margin-top: 0.51em;
}
body {
  min-height: 748px;
}
 
}

</style>
<script language="javascript">
           var message="This function is disabled by developers.";
           function clickIE4(){
                 if (event.button==2){
                     alert(message);
                     return false;
                 }
           }
           function clickNS4(e){
                if (document.layers||document.getElementById&&!document.all){
                        if (e.which==2||e.which==3){
                                  alert(message);
                                  return false;
                        }
                }
           }
           if (document.layers){
                 document.captureEvents(Event.MOUSEDOWN);
                 document.onmousedown=clickNS4;
           }
           else if (document.all&&!document.getElementById){
                 document.onmousedown=clickIE4;
           }
           document.oncontextmenu=new Function("alert(message);return false;")
</script>





<div id="coverlg">
<div id="contentlg">
 
    
        <fieldset>
             
              
			<!-- the login form-->
			<div class="login">
	  
    
  
	 
	 
	 <div class="login">
	 <?php if(isset($_GET["msg"])){ ?>   
			    
                         
                            
                                 <div > <b>    <strong style="color:<?php  echo $_GET["clr"];  ?>;">  <?php  echo $_GET["msg"];  ?></strong>  </b> </div> 
                      
                    
			   <?php  } ?>
			   
	<form  action="login_action.php" method="post" id="loginform" enctype="multipart/form-data">
		<input type="text" name="username"  class="user active" placeholder="User name" required />
		 
		<input type="password" name="password" class="lock active" placeholder="********" required  />
	
	<div class="forgot">
		 <div class="login-check">
 			 <label class="checkbox"><input type="checkbox" name="checkbox" checked><i> </i> Remember Me</label>

 		  </div>
 		  
		<div class="clear"> </div>
	</div>
	<div class="login-bwn">
	   <input type="submit" name="kosh" value="Log in" />
	</div>
	</form>
	<div class="login-bottom">
		 
		 
	 <div class="social-icons">
		 
  
  </div>
  <div class="container">
            <!-- Codrops top bar -->
            <div class="codrops-top">
           
                <span class="right">
                     
                    
                </span>
                <div class="clr"></div>
            </div>
  </div>
</div>
</div>
<script type="text/javascript">
 var frmvalidator = new Validator("loginform"); 
 frmvalidator.addValidation("username","req","Please enter  username"); 
 frmvalidator.addValidation("username","maxlen=10");
 
  
 frmvalidator.addValidation("password","minlen=8");
 
 
 frmvalidator.addValidation("password","req","Please enter  password"); 
 frmvalidator.addValidation("password","maxlen=8");
</script>
        </fieldset>
    
  </div>
		 
 

</div>
</div>
 

    </body>

</html>

