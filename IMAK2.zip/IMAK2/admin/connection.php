<?php
ini_set('post_max_size', '1G');

ini_set('max_execution_time', 3000); 

ini_set('upload_max_filesize', '1G');

$host='localhost';
$user='root';
$pass='';
$db = 'ima';

$con = mysqli_connect($host,$user,$pass,$db);
 


 
?>
