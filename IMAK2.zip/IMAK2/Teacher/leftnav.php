
 
  <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav slimscrollsidebar">
                <div class="sidebar-head">
                    <h3><span class="fa-fw open-close"><i class="ti-close ti-menu"></i></span> <span class="hide-menu">Navigation</span></h3>
                </div>
                <ul class="nav" id="side-menu">
                    
 <li style="padding: 70px 0 0;">
                        <a href="dashboard.php" class="waves-effect"><i class="fa fa-dashboard fa-fw" aria-hidden="true"></i>Dashboard</a>
                    </li>

	 
	 
	 <li>
                        <a href="Student_table.php" class="waves-effect"> <i class="fa fa-table fa-fw" aria-hidden="true"></i>Student</a>
                    </li>
	 
	 
	 <li>
                        <a href="lesson_table.php" class="waves-effect"> <i class="fa fa-table fa-fw" aria-hidden="true"></i>Lesson</a>
                    </li>
	 
	 
	 <li>
                        <a href="message_table.php" class="waves-effect"> <i class="fa fa-table fa-fw" aria-hidden="true"></i>Message</a>
                    </li>
	 
	 