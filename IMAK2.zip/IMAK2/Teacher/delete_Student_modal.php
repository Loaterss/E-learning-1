
 <div class="modal fade" id="myModal<?php echo $id; ?>" tabindex="-1" role="dialog"     aria-labelledby="myModalLabel" aria-hidden="true">    <div class="modal-dialog">       <div class="modal-content">          <div class="modal-header">             <button type="button" class="close"                 data-dismiss="modal" aria-hidden="true">                   &times;             </button>             <h4 class="modal-title" id="myModalLabel">                 DELETE
 
 </h4>          </div>          <div class="modal-body">        Are you Sure you want to Delete this Data?       </div>          <div class="modal-footer">             <button type="button" class="btn btn-default"                 data-dismiss="modal">Close             </button>             <button type="button" class="btn btn-primary"  >     <a class="btn btn-danger" href="delete_Student.php?id=<?php echo $id; ?>">          Submit changes    </a>          </button>          </div>       </div><!-- /.modal-content --> </div><!-- /.modal -->
	
	
	 
	
 
 