<?php
 include 'header.php';
                           
    include "connection.php";
                           ?>
	
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesnot work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>


                            
                                                 
  
                                               

<body class="fix-header">
    <!-- ============================================================== -->
    <!-- Preloader -->
    <!-- ============================================================== -->
   
    <!-- ============================================================== -->
    <!-- Wrapper -->
    <!-- ============================================================== -->
    <div id="wrapper">
        <!-- ============================================================== -->
      
	   
	   
	   <!--  begin extension of left nav   -->
	   </ul>
                <div class="center p-20">
                     <a href="#"  class="btn btn-info btn-block waves-effect waves-light">Edit Profile</a>
                 </div>
            </div>
            
        </div>
        <form class=" form-material" method="POST" action="edit_Student.php" enctype="multipart/form-data" >
       <?php $CLA =  $_SESSION['SESS_MEMBER_ID'];?>
                       <input type="hidden"  name="id" value="<?php echo $CLA;  ?>" required>
                        
                                      <input type="hidden"  name="submitedit"   required>
                       <?php
                                        
                             $CLA =  $_SESSION['SESS_MEMBER_ID'];
                             $sql9="SELECT * FROM `student` WHERE `Student_ID`='$CLA'";
                             $rst9=mysqli_query($con,$sql9);
                             while($rw9=mysqli_fetch_array($rst9)){
                                  
                                           
                                           ?>
                                           

                                           
                                           <div class="form-group">
                             <label class="col-md-12">First Name</label>
                             <div class="col-md-12">
                                           
                                             <input type="text"   name="f_name" placeholder="<?php echo  $rw9["f_name"];    ?>" value="<?php echo  $rw9["f_name"];    ?>"
                                     class="form-control form-control-line">  
                                      </div>
                         </div> 
                              </br>           
                               
                                           
                                           <div class="form-group">
                             <label class="col-md-12">Last Name </label>
                             <div class="col-md-12">
                                           
                                             <input type="text"   name="l_name" placeholder="<?php echo  $rw9["l_name"];    ?>" value="<?php echo  $rw9["l_name"];    ?>"
                                     class="form-control form-control-line">  
                                      </div>
                         </div> 
                              </br>           
                               
                                           
                               
                                           
                                           <div class="form-group">
                             <label class="col-md-12">Username </label>
                             <div class="col-md-12">
                                           
                                             <input type="text"   name="username" placeholder="<?php echo  $rw9["username"];    ?>" value="<?php echo  $rw9["username"];    ?>"
                                     class="form-control form-control-line">  
                                      </div>
                         </div> 
                              </br>           
                               
                                           
                                           <div class="form-group">
                             <label class="col-md-12"> Password </label>
                             <div class="col-md-12">
                                           
                                             <input type="password"   name="password" placeholder="<?php echo  $rw9["password"];    ?>" value="<?php echo  $rw9["password"];    ?>"
                                     class="form-control form-control-line">  
                                      </div>
                         </div> 
                              </br>           
                               
                                           
                                           <div class="form-group">
                             <label class="col-md-12">Class </label>
                             <div class="col-md-12">
                                           
                                             <input type="text"   name="class" placeholder="<?php echo  $rw9["class"];    ?>" value="<?php echo  $rw9["class"];    ?>"
                                     class="form-control form-control-line">  
                                      </div>
                         </div> 
                              </br>           
                             
                        
<?php
                       }
                                            
                                            ?>


                       
                          
                         <div class="form-group">
                             <div class="col-sm-12">
                                 <button class="btn btn-success">Update</button>
                             </div>
                         </div>
                     </form>
                 </div>
             


